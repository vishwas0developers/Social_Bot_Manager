from flask import Flask, render_template, request, jsonify, redirect, url_for, Blueprint
import os
import shutil
import json
import zipfile
import subprocess
import sys
import psutil
import time
from datetime import datetime
from werkzeug.middleware.dispatcher import DispatcherMiddleware

app = Flask(__name__)

# Base paths where Python scripts and images are stored
BASE_PATH = r"C:\Apps\flask_bot_manager\python_scripts"
BASE_DIR = "C:\\Apps\\flask_bot_manager"
SCRIPT_DIR = os.path.join(BASE_DIR, "python_scripts")
BACKUP_DIR = os.path.join(BASE_DIR, "python_scripts_backup")
IMAGE_PATH = os.path.join(app.static_folder, "images")
VENV_PATH = "venv"  # Virtual environment is inside each app folder
JSON_FILE = os.path.join(BASE_PATH, "buttons.json")
TEMP_EXTRACT_PATH = os.path.join(BASE_PATH, "temp_extract")  # Temporary directory for extraction

os.makedirs(BASE_PATH, exist_ok=True)
os.makedirs(IMAGE_PATH, exist_ok=True)

def create_backup(folder_name):
    """Creates a backup of the specified Python script folder with date and time."""
    script_dir = os.path.join(BASE_PATH, folder_name)
    if not os.path.exists(script_dir):
        print(f"❌ Folder '{folder_name}' not found. Skipping backup.")
        return

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    backup_folder_name = f"{folder_name}_{timestamp}"
    backup_path = os.path.join(BACKUP_DIR, backup_folder_name)

    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    shutil.copytree(script_dir, backup_path)
    print(f"✅ Backup created at: {backup_path}")

def load_buttons():
    if os.path.exists(JSON_FILE):
        with open(JSON_FILE, "r") as f:
            return json.load(f)
    return {}

def save_buttons(data):
    with open(JSON_FILE, "w") as f:
        json.dump(data, f, indent=4)

def terminate_process_by_pid(pid):
    """Kill the running process using the stored PID."""
    try:
        proc = psutil.Process(pid)
        proc.terminate()
        proc.wait(timeout=5)
    except psutil.NoSuchProcess:
        print(f"Process with PID {pid} not found.")
    except Exception as e:
        print(f"Failed to terminate PID {pid}: {e}")

def create_button(folder_name):
    buttons_data = load_buttons()
    info = buttons_data.get(folder_name, {})
    return info.get("button_name", folder_name), folder_name, info.get("image", "/static/images/default.png")

@app.route("/")
def index():
    buttons_data = load_buttons()
    buttons = [(info["button_name"], folder, info["image"]) for folder, info in buttons_data.items()]
    return render_template("index.html", buttons=buttons)

@app.route("/upload", methods=["POST"])
def upload():
    zip_file = request.files["zip_file"]
    image_file = request.files.get("image")
    button_name = request.form.get("button_name", "").strip()

    if zip_file and button_name:
        folder_name = "".join(c if c.isalnum() or c in "_-" else "_" for c in button_name).lower()
        script_dir = os.path.join(BASE_PATH, folder_name)

        if os.path.exists(script_dir):
            shutil.rmtree(script_dir)
        os.makedirs(script_dir, exist_ok=True)

        zip_path = os.path.join(BASE_PATH, f"{folder_name}.zip")
        zip_file.save(zip_path)

        if os.path.exists(TEMP_EXTRACT_PATH):
            shutil.rmtree(TEMP_EXTRACT_PATH)
        os.makedirs(TEMP_EXTRACT_PATH, exist_ok=True)

        # Extract zip with progress tracking
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            total_files = len(zip_ref.infolist())
            for i, file_info in enumerate(zip_ref.infolist()):
                zip_ref.extract(file_info, TEMP_EXTRACT_PATH)
                progress = (i + 1) / total_files * 100
                print(f"Extraction Progress: {progress:.2f}%")

        os.remove(zip_path)

        extracted = os.listdir(TEMP_EXTRACT_PATH)
        nested_dir = os.path.join(TEMP_EXTRACT_PATH, extracted[0]) if len(extracted) == 1 and os.path.isdir(os.path.join(TEMP_EXTRACT_PATH, extracted[0])) else TEMP_EXTRACT_PATH

        for item in os.listdir(nested_dir):
            shutil.move(os.path.join(nested_dir, item), script_dir)
        shutil.rmtree(TEMP_EXTRACT_PATH)

        py_files = [f for f in os.listdir(script_dir) if f.endswith(".py")]
        if py_files:
            os.rename(os.path.join(script_dir, py_files[0]), os.path.join(script_dir, "main.py"))
        else:
            shutil.rmtree(script_dir)
            return "Error: No .py file found in ZIP", 400

        req_path = os.path.join(script_dir, "requirements.txt")
        if os.path.exists(req_path):
            pip_path = os.path.join(os.path.dirname(__file__), "app_venv", "Scripts", "pip")
            subprocess.run(f"\"{pip_path}\" install -r \"{req_path}\"", shell=True, check=True)

        buttons_data = load_buttons()
        img_path = "/static/images/default.png"
        if image_file:
            image_file.save(os.path.join(IMAGE_PATH, f"{folder_name}.png"))
            img_path = f"/static/images/{folder_name}.png"

        buttons_data[folder_name] = {"button_name": button_name, "image": img_path}
        save_buttons(buttons_data)

        register_all_apps()

    return redirect(url_for("index"))

@app.route("/delete/<folder_name>")
def delete_script(folder_name):
    script_dir = os.path.join(BASE_PATH, folder_name)
    image_path = os.path.join(IMAGE_PATH, f"{folder_name}.png")
    buttons_data = load_buttons()

    if folder_name in buttons_data and "pid" in buttons_data[folder_name]:
        pid = buttons_data[folder_name]["pid"]
        terminate_process_by_pid(pid)
        del buttons_data[folder_name]["pid"]

    # Unregister blueprint and clean up sys.modules
    if folder_name in app.blueprints:
        app.blueprints.pop(folder_name, None)
    mod_name = f"{folder_name}_app"
    if mod_name in sys.modules:
        del sys.modules[mod_name]

    time.sleep(0.5)

    # Create backup before deletion
    create_backup(folder_name)

    try:
        if os.path.exists(script_dir):
            shutil.rmtree(script_dir)
        if os.path.exists(image_path):
            os.remove(image_path)
        if folder_name in buttons_data:
            del buttons_data[folder_name]
        save_buttons(buttons_data)

        return jsonify({"status": "success", "message": f"Deleted '{folder_name}'"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

@app.route("/edit/<folder_name>", methods=["POST"])
def edit_script(folder_name):
    new_button_name = request.form.get("button_name", "").strip()
    new_zip_file = request.files.get("zip_file")
    new_image_file = request.files.get("image")

    script_dir = os.path.join(BASE_PATH, folder_name)
    buttons_data = load_buttons()

    if folder_name not in buttons_data:
        return jsonify({"status": "error", "message": "App not found."}), 404

    if folder_name in app.blueprints:
        app.blueprints.pop(folder_name, None)
    mod_name = f"{folder_name}_app"
    if mod_name in sys.modules:
        del sys.modules[mod_name]

    if "pid" in buttons_data[folder_name]:
        pid = buttons_data[folder_name]["pid"]
        terminate_process_by_pid(pid)
        del buttons_data[folder_name]["pid"]

    time.sleep(0.5)

    # Create backup before editing
    create_backup(folder_name)

    if os.path.exists(script_dir):
        shutil.rmtree(script_dir)

    # If new ZIP is uploaded
    if new_zip_file and new_zip_file.filename:
        zip_path = os.path.join(BASE_PATH, f"{folder_name}.zip")
        new_zip_file.save(zip_path)
        if os.path.exists(TEMP_EXTRACT_PATH):
            shutil.rmtree(TEMP_EXTRACT_PATH)
        os.makedirs(TEMP_EXTRACT_PATH, exist_ok=True)
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(TEMP_EXTRACT_PATH)
        os.remove(zip_path)

        extracted = os.listdir(TEMP_EXTRACT_PATH)
        nested_dir = os.path.join(TEMP_EXTRACT_PATH, extracted[0]) if len(extracted) == 1 and os.path.isdir(os.path.join(TEMP_EXTRACT_PATH, extracted[0])) else TEMP_EXTRACT_PATH

        os.makedirs(script_dir, exist_ok=True)
        for item in os.listdir(nested_dir):
            shutil.move(os.path.join(nested_dir, item), script_dir)
        shutil.rmtree(TEMP_EXTRACT_PATH)

        py_files = [f for f in os.listdir(script_dir) if f.endswith(".py")]
        if py_files:
            os.rename(os.path.join(script_dir, py_files[0]), os.path.join(script_dir, "main.py"))
        else:
            shutil.rmtree(script_dir)
            return jsonify({"status": "error", "message": "No .py file found in ZIP."}), 400

        req_path = os.path.join(script_dir, "requirements.txt")
        if os.path.exists(req_path):
            pip_path = os.path.join(VENV_PATH, "Scripts", "pip")
            subprocess.run(f"\"{pip_path}\" install -r \"{req_path}\"", shell=True, check=True)

    if new_image_file and new_image_file.filename:
        new_image_file.save(os.path.join(IMAGE_PATH, f"{folder_name}.png"))
        buttons_data[folder_name]["image"] = f"/static/images/{folder_name}.png"

    if new_button_name:
        buttons_data[folder_name]["button_name"] = new_button_name

    save_buttons(buttons_data)
    register_all_apps()
    return jsonify({"status": "success", "message": "App updated successfully"})

def load_uploaded_app(folder_name):
    """Load an app's main.py from the folder and return its Flask instance."""
    import importlib.util

    script_dir = os.path.join(BASE_PATH, folder_name)
    main_script = os.path.join(script_dir, "main.py")

    if not os.path.exists(main_script):
        print(f"⚠️ main.py not found in {script_dir}")
        return None

    # Load and execute main.py dynamically
    spec = importlib.util.spec_from_file_location(f"{folder_name}_app", main_script)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)

    # Return the Flask app instance if available
    return module.app if hasattr(module, "app") else None

def register_all_apps():
    """Register all apps dynamically using DispatcherMiddleware."""
    mapping = {}

    for folder in os.listdir(BASE_PATH):
        script_dir = os.path.join(BASE_PATH, folder)
        if os.path.isdir(script_dir) and os.path.exists(os.path.join(script_dir, "main.py")):
            uploaded_app = load_uploaded_app(folder)
            if uploaded_app:
                mapping[f"/{folder}"] = uploaded_app
            else:
                print(f"⚠️ Failed to load app for {folder}")

    app.wsgi_app = DispatcherMiddleware(app.wsgi_app, mapping)

if __name__ == "__main__":
    register_all_apps()
    app.run(host="0.0.0.0", port=5000, debug=True, use_reloader=False)
